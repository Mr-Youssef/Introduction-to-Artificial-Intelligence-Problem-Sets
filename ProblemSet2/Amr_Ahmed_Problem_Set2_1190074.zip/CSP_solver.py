from typing import Any, Dict, List, Optional
from CSP import Assignment, BinaryConstraint, Problem, UnaryConstraint
from helpers.utils import NotImplemented
import copy
# This function should apply 1-Consistency to the problem.
# In other words, it should modify the domains to only include values that satisfy their variables' unary constraints.
# Then all unary constraints should be removed from the problem (they are no longer needed).
# The function should return False if any domain becomes empty. Otherwise, it should return True.
def one_consistency(problem: Problem) -> bool:
       
    for var in (problem.variables): #looping on all variables in problem
        temp = problem.domains[var].copy() # taking a copy of the domain since dict is immutable
        for val in (temp): #looping on all values for current variable
            for con in (problem.constraints): 
                if (isinstance(con,UnaryConstraint)):   #getting all unary constraints 
                    if((con.variable == var)and(not(con.condition(val)))): #checking for all unary constraints if a value does not satisfy this constraint
                        problem.domains[var].remove(val) #removing said value
                        if (len(problem.domains[var])==0):#if the variable's domain's length ==0, therefore all available values do not satisfy the constrainsts, problem not solvable with available domain
                            return False
                        break  
    for i in (problem.constraints):#removing all unary constraints
        if (isinstance(i,UnaryConstraint)):
            problem.constraints.remove(i)
    return True   


# This function should implement forward checking
# The function is given the problem, the variable that has been assigned and its assigned value and the domains of the unassigned values
# The function should return False if it is impossible to solve the problem after the given assignment, and True otherwise.
# In general, the function should do the following:
#   - For each binary constraints that involve the assigned variable:
#       - Get the other involved variable.
#       - If the other variable has no domain (in other words, it is already assigned), skip this constraint.
#       - Update the other variable's domain to only include the values that satisfy the binary constraint with the assigned variable.
#   - If any variable's domain becomes empty, return False. Otherwise, return True.
# IMPORTANT: Don't use the domains inside the problem, use and modify the ones given by the "domains" argument 
#            since they contain the current domains of unassigned variables only.
def forward_checking(problem: Problem, assigned_variable: str, assigned_value: Any, domains: Dict[str, set]) -> bool:
    for var in (problem.variables):#looping on all variables
        if (not(domains.get(var) == None)):#checking if current var is not assigned beforehand
            temp = domains[var].copy()# taking a copy of the domain since dict is immutable
            for val in (temp):#looping on all values of current var
                for constraint in (problem.constraints):
                    if (isinstance(constraint,BinaryConstraint)):#checking for all binary constraints
                        if (var in constraint.variables and assigned_variable in constraint.variables):
                            if (not(constraint.condition(val,assigned_value))):#checking if a binary constraint is not satisfied by a value in the var's domain
                                domains[var].remove(val)#removing said value
                            if (len(domains[var])==0):#if the variable's domain's length ==0, therefore all available values do not satisfy the constrainsts, problem not solvable with available domain 
                                return False
                            break

    return True 
# This function should return the domain of the given variable order based on the "least restraining value" heuristic.
# IMPORTANT: This function should not modify any of the given arguments.
# Generally, this function is very similar to the forward checking function, but it differs as follows:
#   - You are not given a value for the given variable, since you should do the process for every value in the variable's
#     domain to see how much it will restrain the neigbors domain
#   - Here, you do not modify the given domains. But you can create and modify a copy.
# IMPORTANT: If multiple values have the same priority given the "least restraining value" heuristic, 
#            order them in ascending order (from the lowest to the highest value).
# IMPORTANT: Don't use the domains inside the problem, use and modify the ones given by the "domains" argument 
#            since they contain the current domains of unassigned variables only.
def least_restraining_values(problem: Problem, variable_to_assign: str, domains: Dict[str, set]) -> List[Any]:
    Answer:List[str]=list()
    TupleList:List[int, int]=list(tuple())
    order=-1 #order is negative to work while using sorted(reverse=True)
    for AssignVal in (domains[variable_to_assign]):#looping on all values for the var to assign
        count=0
        for var in problem.variables:
            if (not(domains.get(var)==0)):#checking if variable is not assigned beforehand
                for val in (domains[var]):
                    for constraint in (problem.constraints):
                        if (isinstance(constraint,BinaryConstraint)):
                            if (var in constraint.variables and variable_to_assign in constraint.variables):
                                if (constraint.condition(AssignVal,val)):#checking if value for variable to be assigned and other variable solve the binary constraints
                                    count+=1#increasing the number of available values for other vars other than the one to assign
        TupleList.append((count,order,AssignVal))  #adding number of available values ,order and the value assigned in a list 
        order-=1    #                     
    TupleList.sort(reverse=True)#sorting the list descendingly
  
    for j in TupleList:
        Answer.append(j[2])#returning actions after being sorted
    return Answer


# This function should return the variable that should be picked based on the MRV heuristic.
# IMPORTANT: This function should not modify any of the given arguments.
# IMPORTANT: Don't use the domains inside the problem, use and modify the ones given by the "domains" argument 
#            since they contain the current domains of unassigned variables only.
# IMPORTANT: If multiple variables have the same priority given the MRV heuristic, 
#            order them in the same order in which they appear in "problem.variables".
def minimum_remaining_values(problem: Problem, domains: Dict[str, set]) -> str:
    minvar:str 
    minsize:int = 10000000
    for var in (problem.variables):
        if (not(domains.get(var)==None)):
            if (len(domains[var])<minsize):#saving the variable with the least amount of values
                minsize = len(domains[var])
                minvar = var
    return minvar
    
# This function should solve CSP problems using backtracking search with forward checking.
# The variable ordering should be decided by the MRV heuristic.
# The value ordering should be decided by the "least restraining value" heurisitc.
# Unary constraints should be handled using 1-Consistency before starting the backtracking search.
# This function should return the first solution it finds (a complete assignment that satisfies the problem constraints).
# If no solution was found, it should return None.
# IMPORTANT: To get the correct result for the explored nodes, you should check if the assignment is complete only once using "problem.is_complete"
#            for every assignment including the initial empty assignment, EXCEPT for the assignments pruned by the forward checking.
#            Also, if 1-Consistency deems the whole problem unsolvable, you shouldn't call "problem.is_complete" at all.
def recsolve(problem,assignment,domains): #domains are of unassigned vars
    if problem.is_complete(assignment): #checking if assignment of all values is complete
        if(problem.satisfies_constraints(assignment)): #checking if all assignment satisfies problem constraints
            return assignment
        else:
            return None
   
    var=minimum_remaining_values(problem,domains)#getting var with least num of values
    temp = copy.deepcopy(domains)
    vallist = least_restraining_values(problem,var,temp)#getting list of values in according to least restraining order
    for val in vallist:
        temp2 = copy.deepcopy(domains)
        if (var in problem.variables):
            problem.variables.remove(var)
        flag = forward_checking(problem,var,val,temp2)#checking if value solves all bin constraints 
        if(flag):#if it solves
            assignment[var]=val#include in assignment
            result = recsolve(problem,assignment,temp2)#calling func with new assignment
            if (result is not None):
                return result

    return None

def solve(problem: Problem) -> Optional[Assignment]:
    if (one_consistency(problem)):#if problem is solvable with curr domains
        domcpy = copy.deepcopy(problem.domains)
        Assignment = recsolve(problem,{},domcpy)
        return Assignment
    else:
        return None

