from typing import Tuple
from game import HeuristicFunction, Game, S, A
from helpers.utils import NotImplemented

#TODO: Import any modules you want to use
import math

# All search functions take a problem, a state, a heuristic function and the maximum search depth.
# If the maximum search depth is -1, then there should be no depth cutoff (The expansion should not stop before reaching a terminal state) 

# All the search functions should return the expected tree value and the best action to take based on the search results

# This is a simple search function that looks 1-step ahead and returns the action that lead to highest heuristic value.
# This algorithm is bad if the heuristic function is weak. That is why we use minimax search to look ahead for many steps.
def greedy(game: Game[S, A], state: S, heuristic: HeuristicFunction, max_depth: int = -1) -> Tuple[float, A]:
    agent = game.get_turn(state)
    
    terminal, values = game.is_terminal(state)
    if terminal: return values[agent], None

    actions_states = [(action, game.get_successor(state, action)) for action in game.get_actions(state)]
    value, _, action = max((heuristic(game, state, agent), -index, action) for index, (action , state) in enumerate(actions_states))
    return value, action

# Apply Minimax search and return the game tree value and the best action
# Hint: There may be more than one player, and in all the testcases, it is guaranteed that 
# game.get_turn(state) will return 0 (which means it is the turn of the player). All the other players
# (turn > 0) will be enemies. So for any state "s", if the game.get_turn(s) == 0, it should a max node,
# and if it is > 0, it should be a min node. Also remember that game.is_terminal(s), returns the values
# for all the agents. So to get the value for the player (which acts at the max nodes), you need to
# get values[0].
def minimax(game: Game[S, A], state: S, heuristic: HeuristicFunction, max_depth: int = -1) -> Tuple[float, A]:
    agent = game.get_turn(state)#getting turn
    maxvalue:int =-10000
    maxact:A = None
    minval = 100000
    minact:A =None
    terminal , valuelist = game.is_terminal(state)#checing if curr state is terminal or not
    if terminal: return (valuelist[0],None)#if terminal return U[s]
    if (max_depth==0):
        return (heuristic(game,state,0),None) #if tree has max depth then when depth is reached, return heuristic val
    if (agent==0):#if my player's turn
       for action in game.get_actions(state):#looping on actions
            nodeval = minimax(game,game.get_successor(state,action),heuristic,max_depth-1)[0]
            if (nodeval>maxvalue):#getting max of all node values
                maxvalue=nodeval
                maxact=action
       return (maxvalue,maxact)#returning max action
    if (agent!=0):#if enemy's turn
        for action in game.get_actions(state):
            nodeval = minimax(game,game.get_successor(state,action),heuristic,max_depth-1)[0]
            if (nodeval<minval):#saving min value
                minval=nodeval
                minact=action
        return (minval,minact)#returning min value

# Apply Alpha Beta pruning and return the tree value and the best action
# Hint: Read the hint for minimax.
def alphabeta(game: Game[S, A], state: S, heuristic: HeuristicFunction, max_depth: int = -1,alpha=-1000000,beta=1000000) -> Tuple[float, A]:
    agent = game.get_turn(state)
    maxvalue:int =-10000
    maxact:A = None
    minval = 100000
    minact:A =None
    terminal , value = game.is_terminal(state)
    if terminal: return (value[0],None)
    if (max_depth==0):
        return (heuristic(game,state,0),None) 
    if (agent==0):
       for action in game.get_actions(state):
            nodeval = alphabeta(game,game.get_successor(state,action),heuristic,max_depth-1,alpha,beta)[0]
            if (nodeval>maxvalue):
                maxvalue=nodeval
                maxact=action
            if (nodeval>alpha):#saving new alpha value
                alpha=nodeval
            if (alpha>=beta):#if pruning condition is breached, prune rest of siblings
                break
       return (maxvalue,maxact)#returning max after pruning
    if (agent!=0):
        for action in game.get_actions(state):
            nodeval = alphabeta(game,game.get_successor(state,action),heuristic,max_depth-1,alpha,beta)[0]
            if (nodeval<minval):
                minval=nodeval
                minact=action
            if (nodeval<beta):#saving new beta value
                beta=nodeval
            if (alpha>=beta):#if pruning condition is breached, prune rest of siblings
                break
        return (minval,minact)#returning min after pruning

# Apply Alpha Beta pruning with move ordering and return the tree value and the best action
# Hint: Read the hint for minimax.
def alphabeta_with_move_ordering(game: Game[S, A], state: S, heuristic: HeuristicFunction, max_depth: int = -1,alpha=-10000,beta=10000) -> Tuple[float, A]:
    agent = game.get_turn(state)
    maxvalue:int =-10000
    maxact:A = None
    minval = 100000
    minact:A =None
    tuplelist=list()

    terminal , value = game.is_terminal(state)
    if terminal: return (value[0],None)

    
    if (max_depth==0):
        return (heuristic(game,state,0),None) 
    
    
    actionlist = game.get_actions(state)
    for action in actionlist:#sorting actions according to ideal moving order
        tuplelist.append((heuristic(game,game.get_successor(state,action),agent) ,action ))
    tuplelist=sorted(tuplelist,reverse=True ,key = lambda x:x[0])
    actionlist.clear()
    for acttuple in tuplelist:
        actionlist.append(acttuple[1])
    
    
    if (agent==0):#same as alpha beta pruning
       for action in actionlist:
            nodeval = alphabeta_with_move_ordering(game,game.get_successor(state,action),heuristic,max_depth-1,alpha,beta)[0]
            if (nodeval>maxvalue):
                maxvalue=nodeval
                maxact=action
            if (nodeval>alpha):
                alpha=nodeval
            if (alpha>=beta):
                break
       return (maxvalue,maxact)
    
    if (agent!=0):
        for action in actionlist:
            nodeval = alphabeta_with_move_ordering(game,game.get_successor(state,action),heuristic,max_depth-1,alpha,beta)[0]
            if (nodeval<minval):
                minval=nodeval
                minact=action
            if (nodeval<beta):
                beta=nodeval
            if (alpha>=beta):
                break
        return (minval,minact)
 

# Apply Expectimax search and return the tree value and the best action
# Hint: Read the hint for minimax, but note that the monsters (turn > 0) do not act as min nodes anymore,
# they now act as chance nodes (they act randomly).
def expectimax(game: Game[S, A], state: S, heuristic: HeuristicFunction, max_depth: int = -1) -> Tuple[float, A]:
    agent = game.get_turn(state)
    maxvalue:int =-10000
    maxact:A = None
    nodeval = 0
    minact:A =None
    terminal , valuelist = game.is_terminal(state)
    if terminal: return (valuelist[0],None)
    if (max_depth==0):
        return (heuristic(game,state,0),None) 
    if (agent==0):
       for action in game.get_actions(state):
            nodeval = expectimax(game,game.get_successor(state,action),heuristic,max_depth-1)[0]
            if (nodeval>maxvalue):
                maxvalue=nodeval
                maxact=action
       return (maxvalue,maxact)
    if (agent!=0):#in enemy's turn changing all min nodes to expectations by getting heuristic value for each node, adding them and diving them by their length(assume probability is equal for all values)
        for action in game.get_actions(state):
            nodeval += expectimax(game,game.get_successor(state,action),heuristic,max_depth-1)[0]
        nodeval/=len(game.get_actions(state))
        return (nodeval,minact)
